# ARCIILAB Mini Games

`games/` 폴더에 HTML 게임 파일을 추가하면 홈 화면에 자동으로 게임 카드가 생성됩니다.

게임 HTML은 단일 파일로 만들 수 있으며, 내부의 `<style>`, `<script>`, 외부 CSS/JS도 자동으로 불러옵니다.

GitHub Pages: `main` 브랜치의 `/ (root)`
